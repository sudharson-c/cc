const express = require('express');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();
const port = 3000;

// MongoDB connection string
const uri = "mongodb+srv://LOHITHA:Lohi6331@cluster0.1msqs.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

// Create MongoDB client
const client = new MongoClient(uri, { useUnifiedTopology: true });

// Connect to the MongoDB database
client.connect()
    .then(() => {
        console.log("Connected to MongoDB");
    })
    .catch((err) => {
        console.error("Error in MongoDB connection:", err);
    });

// Middleware for serving static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Serve the index.html file when visiting the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Endpoint to add a food item
app.post('/addfood', async (req, res) => {
    const { name, cost } = req.body;

    const db = client.db('kiosk');
    const collection = db.collection('menu');

    try {
        await collection.insertOne({ name, cost });
        res.status(201).json({ message: 'Food item added' });
    } catch (err) {
        console.error('Error adding food item:', err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Endpoint to get all food items
app.get('/get-food', async (req, res) => {
    const db = client.db('kiosk');
    const collection = db.collection('menu');

    try {
        const foodItems = await collection.find().toArray();
        res.json(foodItems);
    } catch (err) {
        console.error('Error fetching food items:', err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Endpoint to delete a food item
app.delete('/delete-food/:id', async (req, res) => {
    const { id } = req.params;

    const db = client.db('kiosk');
    const collection = db.collection('menu');

    try {
        await collection.deleteOne({ _id: new ObjectId(id) });
        res.status(200).json({ message: 'Food item deleted' });
    } catch (err) {
        console.error('Error deleting food item:', err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Endpoint to update a food item
app.put('/edit-food/:id', async (req, res) => {
    const { id } = req.params;
    const { name, cost } = req.body;

    const db = client.db('kiosk');
    const collection = db.collection('menu');

    try {
        await collection.updateOne(
            { _id: new ObjectId(id) },
            { $set: { name: name, cost: cost } }
        );
        res.status(200).json({ message: 'Food item updated' });
    } catch (err) {
        console.error('Error updating food item:', err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

// Start the server and listen on the specified port
app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});
