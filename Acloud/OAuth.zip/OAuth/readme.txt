dependencies

npm init -y
npm install express

npm init -y
npm install express mongoose body-parser

run the server